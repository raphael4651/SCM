package beans;

public class Calculator {
	public int Process(int n){
		return n*n*n;
	}
}
