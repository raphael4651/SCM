package beans;

public class GuGuDan {
	int i;
	public int Process(int num) {
		return 5 * num;
	}
}
